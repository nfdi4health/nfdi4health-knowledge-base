---
title: About
---

## Who is the RDMkit for?
The ELIXIR Research Data Management Kit (RDMkit) has been designed to guide life scientists in their efforts to better manage their research data following the FAIR Principles. It is based on the various steps of the data lifecycle, although not all the steps will be relevant to everyone.

The contents are generated and maintained by the ELIXIR community. More information on how we want to sustain and govern RDMkit can be found on the [RDMkit Alliance page](rdmkit_alliance).

<div class="card bg-light my-4">
  <div class="card-body">
    <p class="card-text">RDMkit is recommended in the <a href="https://ec.europa.eu/info/funding-tenders/opportunities/docs/2021-2027/horizon/guidance/programme-guide_horizon_en.pdf">Horizon Europe Program Guide</a> as the "resource for Data Management guidelines and good practices for the Life Sciences."</p>
  </div>
</div>

## Why are the FAIR principles needed?
At the heart of FAIR Science lies good data management practice. This is increasingly important as life science research becomes data-intensive and traditional ‘wet labs’ make space for ‘dry (computer) labs’.

With that in mind, the [FAIR Principles](https://www.nature.com/articles/sdata201618) were designed to improve the **F**indability, **A**ccessibility, **I**nteroperability and **R**eusability of data.

The increasing volume, complexity and speed of data creation made scientists rely on computational support exponentially. Therefore, the FAIR Principles place specific emphasis on enhancing the ability of machines to automatically find and use data, as well as supporting its reuse by other scientists, which facilitates knowledge discovery and improves research transparency.

## What does the RDMkit aim to achieve?
More than ever, scientists need relevant tools and guidance to better manage their data and hence contribute to making FAIR Science a reality as well as help researchers be more productive for themselves and their collaborators.

- **For researchers** - RDMkit is a one-stop shop of information, advice and signposting to research data management know-how, tools, examples and best practices. Are you struggling with writing your project's data management plan? RDMkit can help.

- **For data managers in laboratories, facilities or universities** - RDMkit is a resource for your researchers, a complement to your resources and a guide to the specific challenges of RDM for life science researchers. 

- **For funding agencies and policymakers** - RDMkit is the resource researchers can turn to at the proposal stage of the research, throughout their projects and when publishing their results.  Remember that the cost of not having FAIR research data has been estimated at €10.2bn annually in Europe. By using RDMkit and better managing  data, the outcomes of your investments will contribute to strengthening regional, national and European economies.

## Funding acknowledgement
RDMkit was developed with funding from the European Union’s Horizon 2020 Research and Innovation Programme under grant agreement No 871075, as part of the ELIXIR-CONVERGE project. We are grateful to all who contributed their time to producing content for RDMkit. 

## How to cite the RDMkit

When referencing content from the RDMkit pages, please cite as follows:

<div class="card bg-light my-4">
  <div class="card-body">
    <p class="card-text"><i>RDMkit: The ELIXIR Research Data Management toolkit for Life Sciences URL: <a href="https://rdmkit.elixir-europe.org">https://rdmkit.elixir-europe.org </a></i></p>
  </div>
</div>

or using BibTex:

{% raw %}
```
@misc{ELIXIR_RDMkit_The_Research,
author = {ELIXIR},
title = {{RDMkit: The Research Data Management toolkit for Life Sciences}},
url = {https://rdmkit.elixir-europe.org}
}
```
{% endraw %}

To cite the paper about how RDMkit was created please cite:

<div class="card bg-light my-4">
  <div class="card-body">
    <p class="card-text"><i>Alper, P., D’Anna, F., Droesbeke, B., Andrabi, M., Buono, R.A., Bianchini, F., Bösl, K., Chandramouliswaran, I., Cook, M., Faria, D., et al. (2025). RDMkit: A research data management toolkit for life sciences. PATTERNS Volume 6, Issue 9, 101345.<a href="https://doi.org/10.1016/j.patter.2025.101345">https://doi.org/10.1016/j.patter.2025.101345</a>.</i></p>
  </div>
</div>

or using BibTex:

{% raw %}
```
@article{Alper_RDMkit_A_Research_2025,
author = {Alper, Pinar and D'Anna, Flora and Droesbeke, Bert and Andrabi, Munazah and Buono, Rafael Andrade and Bianchini, Federico and Bösl, Korbinian and Chandramouliswaran, Ishwar and Cook, Martin and Faria, Daniel and Fatima, Nazeefa and Hooft, Rob and Jareborg, Niclas and Jetten, Mijke and Pilvar, Diana and Poires-Oliveira, Gil and Popleteeva, Marina and Portell-Silva, Laura and Slifka, Jan and Suchánek, Marek and van Gelder, Celia and Welter, Danielle and Wittig, Ulrike and Coppens, Frederik and Goble, Carole},
doi = {10.1016/j.patter.2025.101345},
journal = {Patterns},
month = aug,
title = {{RDMkit: A Research Data Management Toolkit for Life Sciences}},
url = {https://doi.org/10.1016/j.patter.2025.101345},
year = {2025}
}
```
{% endraw %}

The ELIXIR Research Data Management Kit makes all its materials publicly available under open licenses. Software is released under the [MIT license](https://opensource.org/licenses/mit-license.html) (an [Open Source Initiative-approved](https://opensource.org/licenses) license), while the process documents and data are made available under a [CC-BY](https://creativecommons.org/licenses/by/4.0/) license. For full details on licensing, please visit our [License document on GitHub](https://github.com/elixir-europe/rdmkit/blob/master/LICENSE).


