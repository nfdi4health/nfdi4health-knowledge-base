---

title: <!---REPLACE THIS with full country name in English--->
search_exclude: true
country_code: <!---REPLACE THIS with the ISO 3166-1-alpha-2 country code, capital letters--->
contributors: [<!---REPLACE THIS with comma separated list of contributors--->]
coordinators: [<!---REPLACE THIS with the name of data management coordinators of your ELIXIR node--->]
editors: [<!---REPLACE THIS with comma separated list of editors (to be filled in by an editor)--->]

# Link to other pages in the tool assembly section on the RDMkit by listing the page_id.
# More information on which page_id you can use can be found at https://rdmkit.elixir-europe.org/website_overview 
related_pages:
  Tool_assembly: [<!---REPLACE THIS with the page ID of the tool_assembly pages that you want to list here as related pages--->]

training:
  - name: Training in TeSS
    registry: TeSS
    url: <!--- https://tess.elixir-europe.org/materials?node=NODENAME --->
  - name: ELIXIR NODENAME community in Zenodo
    registry: Zenodo
    url: <!--- https://zenodo.org/communities/elixir NODENAME --->
  - name: ELIXIR NODENAME YouTube
    registry: YouTube
    url: <!--- URL of the channel --->
  - name: <!---REPLACE THIS with the name of your training in registry or platform--->
    registry: <!---REPLACE THIS with the name of the registry--->
    url: <!---REPLACE THIS with the url of your training registry or platform--->

# Refer to entries of the "main_tool_and_resource_table" if institutions, organisations and projects from the country contribute to the development of international tools and resources. 
ref_to_main_resources: 
  -  <!---REPLACE THIS with the tool id--->

# List here tools and resources mainly relevant for the specific country
national_resources: 
  - name: <!---REPLACE THIS with the national resources about RDM in life sciences such as local instances of tools, guidelines or regulations--->
    description:
    how_to_access: <!--- REPLACE THIS free text to explain if credentials, login, specific affiliations, etc., are needed to access the resource or tool--->
    instance_of: <!--- REPLACE THIS with the tool id of which this resource is an instance of, taken from the all tools and resources file --->
    related_pages:
      Tool_assembly: [<!---REPLACE THIS with the page ID of the tool_assembly pages that you want to list here as related pages--->]
      Your_domain: [<!---REPLACE THIS with the page ID of the domain pages that you want to list here as related pages--->]
      Your_role: [<!---REPLACE THIS with the page ID of the your_role pages that you want to list here as related pages--->]
      Your_tasks: [<!---REPLACE THIS with the page ID of the your_tasks pages that you want to list here as related pages--->]
    url:
    registry:
      biotools: <!--- DELETE ME if not needed --->
      fairsharing: <!--- DELETE ME if not needed --->
      tess: <!--- DELETE ME if not needed --->
# More information on how to fill in this metadata section can be found here https://rdmkit.elixir-europe.org/page_metadata
---

<!-- Please take in mind our style guide https://rdmkit.elixir-europe.org/style_guide when writing the content of this page. -->
<!---All the resources added above will appear on the table at the bottom of the page--->

<!---Following information for the page text--->
<!---Use this template as guidance, all fields are optional. Feel free to modify any section if you think it is necessary--->
<!---If the information is already in another resource, please include the link instead of duplicating information--->
<!---Please focus on resources that are relevant for the whole country for life sciences--->

## Introduction 
<!---General RDM considerations for your country, how to deal with RDM on a national level--->

## Funders

## Regulations
<!--- Ethical and legal regulations in the country, committees, etc. --->

## Domain-specific infrastructures or resources 
<!--- e.g. human data, covid-19. Please, only add domain-specific resources that you think don't fit in the table at the bottom--->

<!--- IF APPLICABLE
## Bibliography 

{% bibliography --cited %}


More info on how to use a bibliography can be found in our style guide: https://rdmkit.elixir-europe.org/style_guide#bibliography
--->
