---

title: Sweden
country_code: SE
contributors: [Stephan Nylinder, Yvonne Kallberg, Niclas Jareborg, Markus Englund, Elin Kronander, Elisavet Torstensson, Angela Fuentes Pardo, Sonja Mathias, Natashia Benzian Olsson]
editors: [Bert Droesbeke, Laura Portell Silva]
coordinators: [Niclas Jareborg, Yvonne Kallberg]

training:
  - name: ELIXIR Sweden Training material in TeSS
    registry: TeSS
    url: https://tess.elixir-europe.org/nodes/sweden
  - name: SciLifeLab Data Management YouTube Playlist
    registry: YouTube
    url: https://www.youtube.com/playlist?list=PL1nnHOyxN_WdqnzLqbmWJz_i0f2anT9cS

national_resources:
  - name: NBIS data submission documentation
    description: A GitHub repository with documentation and guidelines for submitting data to domain-specific repositories, provided by NBIS data stewards.
    how_to_access: Available to everyone.
    related_pages:
      Your_tasks: [data_publication]
    url: https://github.com/NBISweden/data-submission-documentation
  - name: Researchdata.se
    description: Researchdata.se is a national web portal where you can find, share, and reuse research data from a wide range of research fields. You can also find helpful advice and recommendations on managing research data.
    how_to_access: Available to everyone.
    related_pages:
      Your_tasks: [existing_data, data_publication, dmp]
    url: https://researchdata.se/en
  - name: Swedish Open Science Portal
    description: The Swedish Open Science Portal is a national knowledge hub for open science in Sweden. It provides information, guidelines, and tools to support researchers and research institutions in implementing open science practices.
    how_to_access: Available to everyone.
    url: https://openscience.se/en/
  - name: SciLifeLab DS-Wizard
    description: Data Stewardship Wizard is a tool to be used when planning for data management, including generating a data management plan (DMP). This instance provides guidance with focus towards Swedish life science researchers, including national resources.   
    how_to_access: ELIXIR AAI login
    instance_of: data-stewardship-wizard
    related_pages:
      Your_tasks: [dmp]
    url: https://dsw.scilifelab.se/ 
  - name: SciLifeLab Data Repository (Figshare)
    description: A repository for publishing life science research outputs that do not fit within existing domain-specific repositories, including datasets, documents, figures, and presentations, hosted on SciLifeLab's local Figshare instance.
    how_to_access: Available to everyone with an affiliation to a Swedish academic institution.
    instance_of: figshare
    related_pages:
      Your_tasks: [existing_data, data_publication]
    url: https://scilifelab.figshare.com/
  - name: NBIS Data Management Consultation
    description: Free consultation service regarding data management questions in life science research.
    how_to_access: Available to everyone with an affiliation to a Swedish academic institution.
    related_pages:
      Your_tasks: [dmp, data_publication, sensitive]
    url: https://nbis.se/services/guidance-on-data-management
  - name: Swedish Pathogens Portal
    description: The Swedish Pathogens Portal provides researchers with information, guidelines, tools and services that enable effective use of national and European infrastructures for sharing data related to pathogens.
    related_pages:
      Tool_assembly: [covid19_data_portal]
      Your_domain: [human_data]
      Your_tasks: [sensitive, existing_data, data_publication]
    url: https://pathogens.se/ 
    instance_of: pathogens-portal
  - name: NAISS 
    description: The National Academic Infrastructure for Super­computing in Sweden (NAISS) is a national research infrastructure that makes available large-scale high-performance computing resources, storage capacity, and advanced user support, for Swedish research.
    how_to_access: An application is required to gain access to the compute and storage services.
    related_pages:
      Your_tasks: [data_analysis, storage]
    url: https://www.naiss.se/ 
  - name: SciLifeLab RDM Guidelines
    description: Knowledge hub for the management of life science research data in Sweden.
    url: https://data-guidelines.scilifelab.se/
  - name: Human Data Guidelines
    description: Guidelines as well as further information on legal considerations when working with human biomedical data.
    related_pages:
      Your_domain: [human_data]
      Your_tasks: [sensitive]
    url: https://data-guidelines.scilifelab.se/topics/research-involving-human-data/
  - name: FEGA Sweden
    description: The Swedish node of Federated European Genome-phenome Archive (FEGA), which offers secure archiving and sharing of genetic and phenotypic data resulting from Swedish biomedical research projects.
    instance_of: the-european-genome-phenome-archive
    related_pages:
      Your_domain: [human_data]
      Your_tasks: [sensitive, existing_data, gdpr_compliance, data_publication]
    url: https://fega.nbis.se/
  - name: Swedish Reference Genome Portal
    description: A web platform for aggregating, sharing, and visualising non-human eukaryotic genome assemblies and genome annotations (co-)produced by researchers affiliated with Swedish institutions.
    related_pages:
      Your_domain: [biodiversity]
      Your_tasks: [existing_data, data_publication]
    url: https://genomes.scilifelab.se/
  - name: SciLifeLab Serve
    description: A platform offering machine learning model serving, app hosting, and other web tools.
    how_to_access: Available to life science researchers affiliated with a Swedish research institute
    url: https://serve.scilifelab.se/
  - name: SciLifeLab Precision Medicine Portal
    description: This portal is a service for researchers in the precision medicine field, designed to support and accelerate data-driven life science research in Sweden. It provides links to various data sources, customised dashboards, and resources for navigating data management challenges. Researchers can also find guidance on handling sensitive data and links to relevant tools and services.
    how_to_access: Available to life science researchers affiliated with a Swedish research institute
    related_pages:
      Your_domain: [health_data, human_data]
      Your_tasks: [existing_data, gdpr_compliance]
    url: https://precision-medicine-portal.scilifelab.se/
  - name: Swedish Biodiversity Data Infrastructure (SBDI)
    description: SBDI is a national research infrastructure that provides access to biodiversity data and related services for researchers in Sweden. SBDI aims to facilitate the use of biodiversity data for research, conservation, and sustainable development.
    how_to_access: Available to everyone.
    related_pages:
      Your_domain: [biodiversity]
      Your_tasks: [existing_data, data_publication]
    url: https://biodiversitydata.se/
  - name: SciLifeLab Training Portal
    description: A portal for finding training events and materials related to life science research data management and bioinformatics in Sweden. Herein, the life science community in Sweden can find opportunities to gain relevant skills, and experts can find support in creating training that captures their knowledge
    url: https://training.scilifelab.se/
  - name: Analytical Imaging Diagnostics Arena (AIDA) Data Hub
    description: AIDA Data Hub is a national infrastructure for secure storing and sharing of multi-modal diagnostics and medical imaging AI.
    how_to_access: An application is required to gain access to the services.
    related_pages:
      Your_domain: [health_data, human_data]
      Your_tasks: [gdpr_compliance]
    url: https://datahub.aida.scilifelab.se/
  - name: SciLifeLab Open Science
    description: A knowledge hub for open science in life science research in Sweden, providing information, guidelines, and tools to support researchers and research institutions in implementing open science practices.
    url: https://data.scilifelab.se/open_science/
---

## Introduction 

This page provides a general overview of national resources on research data management (RDM) and Open Science in Sweden, directed towards researchers and official collaborators. National and long term data management goals and objectives are provided in the research and innovation bill [2024/25:60](https://www.regeringen.se/contentassets/a70996e2f9de4222b5a6880d33c20d35/forskning-och-innovation-for-framtid-nyfikenhet-och-nytta-prop.-20242560.pdf) (in Swedish). The Swedish ELIXIR node [**National Bioinformatics Infrastructure Sweden (NBIS)**](https://nbis.se/) offers support and training in data management to life science researchers in Sweden, in collaboration with the [**SciLifeLab Data Centre**](https://www.scilifelab.se/data/).

## Policies and guidelines

The [**Swedish Research Council**](https://www.vr.se/) has a government mandate to coordinate and promote Sweden’s work on introducing [**open access**](https://www.vr.se/english/mandates/open-science/open-access-to-research-data.html) to research data, with the goal for transition to open access to research data to be fully implemented by 2026. As of 2019, all recipients of grants from the council are required to have a data management plan (DMP), written according to their [**DMP template**](https://www.vr.se/english/applying-for-funding/requirements-terms-and-conditions/producing-a-data-management-plan/data-management-plan-template.html), which is a partially revised version of Science Europe’s "Core Requirements for Data Management Plans".

[**Formas**](https://formas.se/) - The Swedish Research Council for Environment, Agricultural Sciences and Spatial Planning - has a [**policy**](https://formas.se/download/18.7357e3f3168752d5a10c7f7/1549956105856/Beslut_policy_oppna_data.pdf) on open access to research data, and requires that a [**DMP**](https://formas.se/soka-finansiering/sa-har-gar-det-till/att-kanna-till-nar-du-skriver-en-ansokan.html) is written and can be shown upon request.

The National Library of Sweden provides [national guidelines](https://www.kb.se/for-bibliotekssektorn/eng/open-science/national-guidelines-for-open-science.html) intended to provide support and guidance for the different stakeholders in Sweden who have overarching responsibility in the transition to open science. The purpose of these guidelines is to outline the direction for the continued development towards open science in Sweden, specifying which key actors are responsible for what, as well as how the guidelines are to be monitored and updated over time.

Many universities have established data and open access policies, for more information contact the Research Data Office (RDO) (see list at the end of the page).

## Authorities and Regulations

If personal data is processed in your research, contact your organisation’s Data Protection Officer (DPO) (see list at the end of the page), for guidance on ethical and legal compliance. 

The following is a list of ethical and legal committees, authorities and regulations of interest:

### Authorities

* [Swedish Ethical Review Authority](https://etikprovningsmyndigheten.se/)
* [Swedish Authority for Privacy Protection (IMY)](https://www.imy.se/en/)

### Regulations

* [The Ethics Review Act](https://www.riksdagen.se/sv/dokument-lagar/dokument/svensk-forfattningssamling/lag-2003460-om-etikprovning-av-forskning-som_sfs-2003-460) (in Swedish)
* [The Patient Data Act](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/biobankslag-202338_sfs-2023-38/) (in Swedish)
* [The Biobank Act](https://www.riksdagen.se/sv/dokument-lagar/dokument/svensk-forfattningssamling/lag-2002297-om-biobanker-i-halso--och_sfs-2002-297) (in Swedish)
* [The Archives Act](https://www.riksdagen.se/sv/dokument-lagar/dokument/svensk-forfattningssamling/arkivlag-1990782_sfs-1990-782) (in Swedish)
* [Lag (2018:218) med kompletterande bestämmelser till EU:s dataskyddsförordning](https://www.riksdagen.se/sv/dokument-lagar/dokument/svensk-forfattningssamling/lag-2018218-med-kompletterande-bestammelser_sfs-2018-218)
* [The Public Access to Information and Secrecy Act (2009:400)](https://www.riksdagen.se/sv/dokument-och-lagar/dokument/svensk-forfattningssamling/offentlighets-och-sekretesslag-2009400_sfs-2009-400/) (in Swedish)
* [General Data Protection Regulation (GDPR)](https://eur-lex.europa.eu/EN/legal-content/summary/general-data-protection-regulation-gdpr.html)

## Domain-specific infrastructures and resources 

[SciLifeLab Data Management Support](https://data-guidelines.scilifelab.se/) offers tools, guidance, training and hands-on support on various aspects of research data management, such as data management planning, data publishing, guidance on working with sensitive human data, implementing FAIR data principles, and more. The services are provided as a collaboration between [NBIS Data Management team](https://nbis.se/services/guidance-on-data-management) and the [SciLifeLab Data Centre](http://data.scilifelab.se/).

For sensitive human data, a key resource is [**FEGA Sweden**](https://fega.nbis.se/), a secure data archive and sharing platform for sensitive datasets, which is integrated with the {% tool "the-european-genome-phenome-archive" %}.

The [**National Academic Infrastructure for Super­computing in Sweden**](https://www.naiss.se/) (NAISS) is a national research infrastructure that offers compute and storage resources, as well as user support, for researchers across all scientific disciplines in Sweden. Of particular relevance for life science researchers working with sensitive data is [**NAISS-SENS**](https://supr.naiss.se/round/open_or_pending_type/?type=NAISS+SENS), through which researchers can apply for high-performance computing resources for the analysis of sensitive data.

[**Swedish National Data Service**](https://snd.gu.se/en) (SND), with its network of almost 40 higher education institutions and public research institutes, provides researchers with a coordinated and quality-assured system for finding, describing, and sharing research data, nationally as well as internationally. The [**SND network**](https://snd.gu.se/en/about-us/snd-network) has agreed to create local units for managing research data (Data Access Units (DAUs)), with the main task to assist researchers in their respective organisation in making research data as accessible as possible, via training and support in data management. SND also provides a [**DMP checklist**](https://snd.gu.se/en/manage-data/guides/dmp-checklist) to support researchers in writing data management plans. In order to promote reuse and open access to data, SND has established [**Researchdata.se**](https://researchdata.se/en), which serves as a portal for information on data management as well as a data catalogue to a variety of research fields.
 
List of universities with established Research Data Offices (RDOs) or Data Access Units (DAUs), with links to local online resources and contact information. Note that "RDO" and "DAU" are used here as functional descriptions; the corresponding units may have different names at each university.
* Chalmers University of Technology - [RDO Support](https://www.chalmers.se/en/infrastructure/ecommons/storage-and-data-management/reserch-data-management-support/) - <dataoffice@chalmers.se> - [DPO support](https://www.chalmers.se/en/about-chalmers/about-the-website/processing-of-personal-data/) - <>
* Karolinska Institutet - [RDO Support](https://staff.ki.se/research-support/research-data-management) - <rdo@ki.se> - [DPO support](https://staff.ki.se/personal-data-in-research) - <dataskyddsombud@ki.se>
* KTH Royal Institute of Technology - [RDO Support](https://www.kth.se/en/biblioteket/publicera-analysera/hantera-forskningsdata/) - <researchdata@kth.se> - [DPO support](https://intra.kth.se/en/anstallning/anstallningsvillkor/att-vara-statligt-an/behandling-av-person) - <dataskyddsombud@kth.se>
* Linköping University - [RDO Support](https://ep.liu.se/en/datamanagement.aspx) - <datamanagement@liu.se> - <dataskyddsombud@liu.se>
* Linnaeus University - [RDO Support](https://lnu.se/en/medarbetare/researcher/researcher5/research-data/) - <dau@lnu.se> - [DPO support](https://lnu.se/en/medarbetare/support-and-service/forvaltningsrattsliga-fragor/general-data-protection-regulation-gdpr/) - <dataskyddsombud@lnu.se>
* Lund University - [RDO Support](https://www.lub.lu.se/en/services-and-support/research-data) - <support@researchdata.lu.se> - [DPO support](https://www.staff.lu.se/support-and-tools/legal-and-records-management/personal-data-and-data-protection/area-specific-information/research) - <dataskyddsombud@lu.se>
* Stockholm University - [RDO Support](https://medarbetare.su.se/en/research/your-research) - <opendata@su.se> - [DPO support](https://medarbetare.su.se/en/support-and-service/legal/personal-data-and-data-protection) - <dso@su.se>
* Swedish University of Agricultural Sciences - [RDO Support](https://internt.slu.se/en/support-services/data-management-support-for-research-and-environmental-assessment/#stod) - <dms@slu.se> - [DPO support](https://internt.slu.se/en/support-services/administrative-support/legal-affairs-data-protection-info-management/data-protection/) - <dataskydd@slu.se>
* Umeå University - [RDO Support](https://www.umu.se/en/library/research-data/) - See [contact page](https://www.umu.se/en/researcher/plan-and-implement/manage-research-data/support-regarding-research-data/contact-the-research-data-support-team/) - [DPO support](https://www.aurora.umu.se/stod-och-service/rad-och-riktlinjer/juridik-och-personuppgifter/personuppgifter) - <pulo@umu.se>
* University of Gothenburg - [RDO Support](https://gunet.sharepoint.com/sites/mp-utbildning-och-forskning/SitePages/en/Research-data-management.aspx) - <researchdata@gu.se> - [DPO support](https://medarbetarportalen.gu.se/processing-personal-data) - <dataskydd@gu.se>
* Uppsala University - [RDO Support](https://www.uu.se/en/staff/gateway/research/research-data) - <dataoffice@uu.se> - [DPO support](https://www.uu.se/en/staff/service-and-tools/general-data-protection-regulation-gdpr) - <dataskyddsombud@uu.se>
* Örebro University - [RDO Support](https://www.oru.se/english/research/research-support/starting-up-your-research-project/data-management-plan-components/do-you-need-help-with-your-research-data/) - See web page for contact information - [DPO support](https://www.oru.se/forskning/forskningsstod/starta-projekt/dataskyddgdpr---forskning/) - <dataskyddsombud@oru.se>
